import pytest
import json
from langgraph.types import Command, interrupt
from langgraph.errors import GraphInterrupt
from src.graph.builder import build_graph
from src.state.state import default_state, PipelineStage, JudgeVerdict


SAMPLE_REQUIREMENT = (
    "The OMNI Jurisdiction K Streams job must be updated to reflect new compliance "
    "routing rules. The job consumes messages from the Kafka topic "
    "'omni.jurisdiction.k.raw.events'. Each message payload contains the following "
    "fields: jurisdiction_code (string), transaction_amount (float), account_status "
    "(string, values: ACTIVE, SUSPENDED, CLOSED), and kyc_verified (boolean). "
    "Routing rules: if jurisdiction_code is exactly 'K' AND transaction_amount is "
    "greater than 0.0 AND account_status is 'ACTIVE' AND kyc_verified is true, route "
    "to 'omni.jurisdiction.k.compliant.events'. All other conditions route to "
    "'omni.jurisdiction.k.noncompliant.events'. Edge cases: transaction_amount of "
    "exactly 0.0 is non-compliant. A missing kyc_verified field is non-compliant. "
    "A jurisdiction_code of 'k' (lowercase) is non-compliant. A null account_status "
    "is non-compliant."
)


@pytest.fixture(scope="module")
def compiled_graph():
    return build_graph()


def test_stage1_qa_interaction_high_confidence(compiled_graph):
    """Verify QA Interaction Agent completes with a detailed requirement."""
    state = default_state(SAMPLE_REQUIREMENT)
    config = {"configurable": {"thread_id": "test-thread-k-001"}}

    try:
        result = compiled_graph.invoke(state, config=config)
    except GraphInterrupt as gi:
        snapshot = compiled_graph.get_state(config)
        result = snapshot.values

    assert result is not None
    assert result["current_stage"] in (
        PipelineStage.REQUIREMENTS_SPEC,
        PipelineStage.JUDGE_SPEC,
        PipelineStage.GATE_SPEC,
    )
    assert result["clarified_requirement"] is not None
    assert len(result["clarified_requirement"]) > 0
    assert isinstance(result["confidence_score"], float)
    assert 0.0 <= result["confidence_score"] <= 1.0
    assert result["requirements_spec"] is not None


def test_stage2_requirements_spec_structure(compiled_graph):
    """Verify the requirements spec contains all six mandatory sections."""
    config = {"configurable": {"thread_id": "test-thread-k-001"}}
    snapshot = compiled_graph.get_state(config)
    spec = snapshot.values.get("requirements_spec")

    assert spec is not None
    spec_lower = spec.lower()
    assert "overview" in spec_lower
    assert "what is changing" in spec_lower
    assert "jurisdiction routing rules" in spec_lower
    assert "expected behaviour" in spec_lower
    assert "edge cases" in spec_lower
    assert "out of scope" in spec_lower


def test_stage3_judge_spec_verdict(compiled_graph):
    """Verify the judge evaluated the spec and produced a valid verdict."""
    config = {"configurable": {"thread_id": "test-thread-k-001"}}
    snapshot = compiled_graph.get_state(config)
    values = snapshot.values

    assert values.get("judge_verdict") is not None
    assert isinstance(values.get("judge_verdict"), JudgeVerdict)
    assert isinstance(values.get("judge_score"), int)
    assert 0 <= values.get("judge_score") <= 100

    if values.get("judge_verdict") == JudgeVerdict.FAIL:
        assert values.get("judge_feedback") is not None
        assert len(values.get("judge_feedback")) > 0


def test_gate_spec_human_approval_flow(compiled_graph):
    """Simulate human APPROVING the spec at Gate #1."""
    config = {"configurable": {"thread_id": "test-thread-k-001"}}
    snapshot = compiled_graph.get_state(config)

    if not snapshot.next or "gate_spec_node" not in snapshot.next:
        print(f"Current stage: {snapshot.values.get('current_stage')}")
        print(f"Next nodes: {snapshot.next}")
        pytest.skip(
            "Pipeline did not reach gate_spec_node — judge likely FAILed. "
            "Check judge verdict."
        )

    resume_value = {"decision": "APPROVED", "feedback": "Looks good."}
    try:
        result = compiled_graph.invoke(Command(resume=resume_value), config=config)
    except GraphInterrupt as gi:
        snapshot = compiled_graph.get_state(config)
        result = snapshot.values

    assert result["human_decision"] == "APPROVED"
    assert result["current_stage"] in (
        PipelineStage.TEST_CASE_GENERATION,
        PipelineStage.JUDGE_TEST_CASES,
        PipelineStage.GATE_TEST_CASES,
    )
    assert result["test_cases"] is not None
    assert len(result["test_cases"]) > 0
    assert result["judge_retry_count"] == 0


def test_stage4_test_cases_structure(compiled_graph):
    """Verify the structure of every test case in the generated list."""
    config = {"configurable": {"thread_id": "test-thread-k-001"}}
    snapshot = compiled_graph.get_state(config)
    test_cases = snapshot.values.get("test_cases")

    assert test_cases is not None
    assert len(test_cases) > 0

    valid_categories = {"positive", "negative", "boundary", "malformed"}
    for item in test_cases:
        assert isinstance(item, dict)
        assert "id" in item
        assert "scenario" in item
        assert "expected_outcome" in item
        assert "category" in item
        assert item["category"] in valid_categories
        assert item["id"].startswith("TC-")

    categories_present = {item["category"] for item in test_cases}
    assert "positive" in categories_present
    assert "negative" in categories_present
    assert "malformed" in categories_present


def test_gate_test_cases_human_approval_flow(compiled_graph):
    """Simulate human APPROVING at Gate #2 — the final MVP boundary."""
    config = {"configurable": {"thread_id": "test-thread-k-001"}}
    snapshot = compiled_graph.get_state(config)

    if not snapshot.next or "gate_test_cases_node" not in snapshot.next:
        print(f"Current stage: {snapshot.values.get('current_stage')}")
        print(f"Next nodes: {snapshot.next}")
        pytest.skip("Pipeline did not reach gate_test_cases_node.")

    resume_value = {"decision": "APPROVED", "feedback": "Test cases approved."}
    try:
        result = compiled_graph.invoke(Command(resume=resume_value), config=config)
    except GraphInterrupt as gi:
        snapshot = compiled_graph.get_state(config)
        result = snapshot.values

    assert result["human_decision"] == "APPROVED"
    assert result["current_stage"] == PipelineStage.DATA_STRATEGY
