from pathlib import Path


_THIS_DIR = Path(__file__).parent
_PROJECT_ROOT = _THIS_DIR.parent.parent
PROMPTS_DIR = _PROJECT_ROOT / "context" / "prompts"
CONTEXT_DIR = _PROJECT_ROOT / "context"


def load_prompt(prompt_name: str, variables: dict | None = None) -> str:
    """
    Load a prompt markdown file from context/prompts/ and perform
    variable substitution.

    Args:
        prompt_name: Filename without extension. E.g. "qa_interaction_system"
                     loads context/prompts/qa_interaction_system.md
        variables:   Dict of substitution variables. Keys match {placeholders}
                     in the prompt file. Pass None or empty dict if no
                     substitution is needed.

    Returns:
        The prompt string with all variables substituted.

    Raises:
        FileNotFoundError: If the prompt file does not exist.
        ValueError: If a required variable placeholder is missing from
                    the variables dict.
    """
    prompt_path = PROMPTS_DIR / f"{prompt_name}.md"

    if not prompt_path.exists():
        raise FileNotFoundError(
            f"Prompt file not found: {prompt_path}. "
            f"Available prompts: {[p.stem for p in PROMPTS_DIR.glob('*.md')]}"
        )

    template = prompt_path.read_text(encoding="utf-8")

    if variables:
        try:
            return template.format_map(variables)
        except KeyError as e:
            raise ValueError(
                f"Prompt '{prompt_name}' contains placeholder {e} "
                f"but it was not found in the provided variables dict. "
                f"Provided keys: {list(variables.keys())}"
            ) from e

    return template


def load_context_file(filename: str) -> str:
    """
    Load a context markdown file from context/ directory.
    Used to load tech_context.md and codebase_map.md into agent calls.

    Args:
        filename: Full filename including extension.
                  E.g. "tech_context.md", "codebase_map.md"

    Returns:
        The file contents as a plain string.

    Raises:
        FileNotFoundError: If the context file does not exist.
    """
    context_path = CONTEXT_DIR / filename

    if not context_path.exists():
        raise FileNotFoundError(
            f"Context file not found: {context_path}"
        )

    return context_path.read_text(encoding="utf-8")
