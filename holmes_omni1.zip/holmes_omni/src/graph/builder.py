from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt
from src.state.state import (
    AgentState,
    JudgeVerdict,
    PipelineStage,
    default_state,
)
from src.agents.qa_interaction import qa_interaction_node
from src.agents.requirements_spec import requirements_spec_node
from src.agents.judge_spec import judge_spec_node
from src.agents.test_case_generation import test_case_generation_node
from src.agents.judge_test_cases import judge_test_cases_node


# ── Simple Node Stubs ──────────────────────────────────────────────────────








def data_strategy_node(state: AgentState) -> dict:
    return {"current_stage": PipelineStage.DATA_STRATEGY}


def data_generation_node(state: AgentState) -> dict:
    return {"current_stage": PipelineStage.DATA_GENERATION}


def script_writing_node(state: AgentState) -> dict:
    return {"current_stage": PipelineStage.SCRIPT_WRITING}


def sandbox_execution_node(state: AgentState) -> dict:
    return {"current_stage": PipelineStage.SANDBOX_EXECUTION}


def gitlab_push_node(state: AgentState) -> dict:
    return {"current_stage": PipelineStage.GITLAB_PUSH}


# ── Judge Node Stubs ───────────────────────────────────────────────────────






def judge_script_node(state: AgentState) -> dict:
    retry_count = state.get("judge_retry_count", 0) + 1
    verdict = JudgeVerdict.PASS
    feedback = None
    if retry_count >= 3:
        verdict = JudgeVerdict.NEEDS_HUMAN
        feedback = "Maximum retries reached. Manual review required."
    return {
        "current_stage": PipelineStage.JUDGE_SCRIPT,
        "judge_verdict": verdict,
        "judge_score": 99,
        "judge_feedback": feedback,
        "judge_retry_count": retry_count,
    }


# ── Gate Node Stubs ────────────────────────────────────────────────────────


def gate_spec_node(state: AgentState) -> dict:
    human_response = interrupt(state["interrupt_payload"])
    return {
        "current_stage": PipelineStage.GATE_SPEC,
        "human_decision": human_response.get("decision"),
        "human_feedback": human_response.get("feedback"),
        "interrupt_payload": None,
        "judge_retry_count": 0,
    }


def gate_test_cases_node(state: AgentState) -> dict:
    human_response = interrupt(state["interrupt_payload"])
    return {
        "current_stage": PipelineStage.GATE_TEST_CASES,
        "human_decision": human_response.get("decision"),
        "human_feedback": human_response.get("feedback"),
        "interrupt_payload": None,
        "judge_retry_count": 0,
    }


def gate_script_node(state: AgentState) -> dict:
    human_response = interrupt(state["interrupt_payload"])
    return {
        "current_stage": PipelineStage.GATE_SCRIPT,
        "human_decision": human_response.get("decision"),
        "human_feedback": human_response.get("feedback"),
        "interrupt_payload": None,
        "judge_retry_count": 0,
    }


# ── Self-Healing Stub ──────────────────────────────────────────────────────


def self_healing_node(state: AgentState) -> dict:
    return {"current_stage": PipelineStage.SELF_HEALING}


# ── Routing Functions ──────────────────────────────────────────────────────


def route_after_judge_spec(state: AgentState) -> str:
    verdict = state.get("judge_verdict")
    if verdict == JudgeVerdict.FAIL:
        return "requirements_spec_node"
    return "gate_spec_node"


def route_after_judge_test_cases(state: AgentState) -> str:
    verdict = state.get("judge_verdict")
    if verdict == JudgeVerdict.FAIL:
        return "test_case_generation_node"
    return "gate_test_cases_node"


def route_after_judge_script(state: AgentState) -> str:
    verdict = state.get("judge_verdict")
    if verdict == JudgeVerdict.FAIL:
        return "script_writing_node"
    return "gate_script_node"


def route_after_gate_spec(state: AgentState) -> str:
    decision = state.get("human_decision")
    if decision in ("APPROVED", "EDITED"):
        return "test_case_generation_node"
    return "requirements_spec_node"


def route_after_gate_test_cases(state: AgentState) -> str:
    decision = state.get("human_decision")
    if decision in ("APPROVED", "EDITED"):
        return "data_strategy_node"
    return "test_case_generation_node"


def route_after_gate_script(state: AgentState) -> str:
    decision = state.get("human_decision")
    if decision in ("APPROVED", "EDITED"):
        return "sandbox_execution_node"
    return "script_writing_node"


def route_after_self_healing(state: AgentState) -> str:
    if state.get("defect_flag"):
        return END
    if state.get("execution_exit_code") == 0:
        return "gitlab_push_node"
    if state.get("healing_retry_count", 0) >= 3:
        return END
    return "sandbox_execution_node"


# ── Graph Builder ──────────────────────────────────────────────────────────


def build_graph():
    """
    Builds and compiles the HOLMESforOMNI LangGraph StateGraph.
    Returns a compiled graph with MemorySaver checkpointer.
    Call this once at application startup.
    """
    builder = StateGraph(AgentState)

    # ── Register all nodes ──────────────────────────────────────────
    builder.add_node("qa_interaction_node", qa_interaction_node)
    builder.add_node("requirements_spec_node", requirements_spec_node)
    builder.add_node("judge_spec_node", judge_spec_node)
    builder.add_node("gate_spec_node", gate_spec_node)
    builder.add_node("test_case_generation_node", test_case_generation_node)
    builder.add_node("judge_test_cases_node", judge_test_cases_node)
    builder.add_node("gate_test_cases_node", gate_test_cases_node)
    builder.add_node("data_strategy_node", data_strategy_node)
    builder.add_node("data_generation_node", data_generation_node)
    builder.add_node("script_writing_node", script_writing_node)
    builder.add_node("judge_script_node", judge_script_node)
    builder.add_node("gate_script_node", gate_script_node)
    builder.add_node("sandbox_execution_node", sandbox_execution_node)
    builder.add_node("self_healing_node", self_healing_node)
    builder.add_node("gitlab_push_node", gitlab_push_node)

    # ── Wire edges ──────────────────────────────────────────────────
    builder.add_edge(START, "qa_interaction_node")
    builder.add_edge("qa_interaction_node", "requirements_spec_node")
    builder.add_edge("requirements_spec_node", "judge_spec_node")
    builder.add_conditional_edges("judge_spec_node", route_after_judge_spec)
    builder.add_conditional_edges("gate_spec_node", route_after_gate_spec)
    builder.add_edge("test_case_generation_node", "judge_test_cases_node")
    builder.add_conditional_edges("judge_test_cases_node", route_after_judge_test_cases)
    builder.add_conditional_edges("gate_test_cases_node", route_after_gate_test_cases)
    builder.add_edge("data_strategy_node", "data_generation_node")
    builder.add_edge("data_generation_node", "script_writing_node")
    builder.add_edge("script_writing_node", "judge_script_node")
    builder.add_conditional_edges("judge_script_node", route_after_judge_script)
    builder.add_conditional_edges("gate_script_node", route_after_gate_script)
    builder.add_edge("sandbox_execution_node", "self_healing_node")
    builder.add_conditional_edges("self_healing_node", route_after_self_healing)
    builder.add_edge("gitlab_push_node", END)

    # ── Compile with MemorySaver checkpointer ───────────────────────
    checkpointer = MemorySaver()
    return builder.compile(checkpointer=checkpointer)
