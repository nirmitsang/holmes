from src.state.state import AgentState, PipelineStage
from src.agents.llm_client import call_llm
from src.prompts.prompt_loader import load_prompt, load_context_file


def requirements_spec_node(state: AgentState) -> dict:
    """
    Requirements Specification Agent — Stage 2 of the HOLMESforOMNI pipeline.

    Consumes the clarified requirement produced by Stage 1 and generates
    a structured markdown requirements specification document. The spec
    is the single source of truth for all downstream stages.

    No interrupt loop. No JSON parsing. Single LLM call.
    The raw markdown response is returned directly as requirements_spec.

    Also pre-builds the interrupt_payload for the downstream judge/gate
    cycle so the judge node has full context without re-reading state.

    Args:
        state: Current AgentState. Reads: clarified_requirement.

    Returns:
        Partial AgentState dict with keys:
        current_stage, requirements_spec, interrupt_payload.
    """
    # Step 1: Load context and system prompt
    tech_context = load_context_file("tech_context.md")
    system_prompt = load_prompt("requirements_spec_system")

    # Step 2: Build user prompt with substitution variables
    user_prompt = load_prompt(
        "requirements_spec_user",
        {
            "clarified_requirement": state["clarified_requirement"],
            "tech_context": tech_context,
        },
    )

    # Step 3: Call LLM — assign response directly, no parsing
    requirements_spec = call_llm(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
    )

    # Step 4: Pre-build interrupt_payload for the judge/gate cycle
    interrupt_payload = {
        "gate_name": "Review Requirements Spec",
        "data_to_review": requirements_spec,
        "context_message": "Requirements spec generated. Pending judge evaluation.",
    }

    # Step 5: Return state dict
    return {
        "current_stage": PipelineStage.REQUIREMENTS_SPEC,
        "requirements_spec": requirements_spec,
        "interrupt_payload": interrupt_payload,
    }
