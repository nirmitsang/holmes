import json
from langgraph.types import interrupt
from src.state.state import AgentState, PipelineStage
from src.agents.llm_client import call_llm
from src.prompts.prompt_loader import load_prompt, load_context_file


CONFIDENCE_THRESHOLD = 0.85


def _extract_json(response: str) -> dict:
    """
    Extract the trailing JSON block from the LLM response string.

    Uses rfind('{') to locate the last opening brace, ensuring we
    always parse the final structured JSON block even if the LLM
    produces JSON-like text earlier in its response.

    Args:
        response: Raw string response from call_llm().

    Returns:
        Parsed dict with keys: confidence_score, clarification_questions,
        clarified_requirement.

    Raises:
        ValueError: If no JSON block is found or the JSON is malformed.
    """
    start = response.rfind("{")
    if start == -1:
        raise ValueError(
            "QA Interaction Agent returned no JSON block. "
            f"Raw response (first 300 chars): {response[:300]}"
        )
    try:
        return json.loads(response[start:])
    except json.JSONDecodeError as e:
        raise ValueError(
            f"QA Interaction Agent returned malformed JSON. "
            f"Parse error: {e}. "
            f"Attempted to parse: {response[start:start + 300]}"
        ) from e


def qa_interaction_node(state: AgentState) -> dict:
    """
    QA Interaction Agent — Stage 1 of the HOLMESforOMNI pipeline.

    Analyses the raw release requirement, asks targeted clarifying
    questions via interrupt() if confidence is below threshold, and
    produces a structured clarified requirement for Stage 2.

    Interrupt behaviour:
        - Round 1: If confidence < 0.85, interrupts with clarifying
          questions. interrupt() returns a plain string (engineer's answers).
        - Round 2: Always final. Proceeds regardless of confidence score.
        - Maximum 2 clarification rounds. Pipeline never blocked indefinitely.

    Args:
        state: Current AgentState. Reads: raw_requirement.

    Returns:
        Partial AgentState dict with keys:
        current_stage, clarified_requirement, confidence_score,
        clarification_questions, interrupt_payload.
    """
    # Step 1: Load context and system prompt
    tech_context = load_context_file("tech_context.md")
    system_prompt = load_prompt("qa_interaction_system")

    # Step 2: Build Round 1 user prompt and call LLM
    user_prompt_round_1 = load_prompt(
        "qa_interaction_user",
        {
            "raw_requirement": state["raw_requirement"],
            "clarification_round": "1",
            "engineer_answers": "N/A",
            "tech_context": tech_context,
        },
    )
    response_round_1 = call_llm(
        system_prompt=system_prompt,
        user_prompt=user_prompt_round_1,
    )

    # Step 3: Parse Round 1 JSON response
    parsed_round_1 = _extract_json(response_round_1)
    confidence = float(parsed_round_1.get("confidence_score", 0.0))
    questions = parsed_round_1.get("clarification_questions", [])
    clarified = parsed_round_1.get("clarified_requirement", "")

    # Step 4: Interrupt for clarification if confidence is below threshold
    if confidence < CONFIDENCE_THRESHOLD and len(questions) > 0:
        interrupt_payload = {
            "gate_name": "QA Clarification — Round 1",
            "data_to_review": questions,
            "context_message": (
                f"The QA Agent has analysed the requirement and scored "
                f"confidence at {confidence:.0%}. "
                f"Please answer the following questions to proceed."
            ),
        }

        engineer_answers = interrupt(interrupt_payload)

        user_prompt_round_2 = load_prompt(
            "qa_interaction_user",
            {
                "raw_requirement": state["raw_requirement"],
                "clarification_round": "2",
                "engineer_answers": engineer_answers,
                "tech_context": tech_context,
            },
        )

        response_round_2 = call_llm(
            system_prompt=system_prompt,
            user_prompt=user_prompt_round_2,
        )

        parsed_round_2 = _extract_json(response_round_2)
        confidence = float(parsed_round_2.get("confidence_score", 0.0))
        questions = parsed_round_2.get("clarification_questions", [])
        clarified = parsed_round_2.get("clarified_requirement", "")

    # Step 5: Return final state — interrupt_payload always cleared
    return {
        "current_stage": PipelineStage.QA_INTERACTION,
        "clarified_requirement": clarified,
        "confidence_score": confidence,
        "clarification_questions": questions,
        "interrupt_payload": None,
    }
