import json
from src.state.state import AgentState, PipelineStage
from src.agents.llm_client import call_llm
from src.prompts.prompt_loader import load_prompt, load_context_file


def _extract_json_array(response: str) -> list:
    """
    Extract a JSON array from the LLM response string.

    Locates the first '[' and last ']' in the response, slices that
    substring, and parses it as JSON. This handles cases where the LLM
    produces preamble text before or after the array.

    Args:
        response: Raw string response from call_llm().

    Returns:
        Parsed list of test case dicts.

    Raises:
        ValueError: If no JSON array is found, the JSON is malformed,
                    or the parsed result is not a list.
    """
    response = response.strip()
    start = response.find("[")
    end = response.rfind("]")
    if start == -1 or end == -1:
        raise ValueError(
            "Test Case Generation Agent returned no JSON array. "
            f"Raw response (first 300 chars): {response[:300]}"
        )
    array_str = response[start:end + 1]
    try:
        result = json.loads(array_str)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Test Case Generation Agent returned malformed JSON array. "
            f"Parse error: {e}. "
            f"Attempted to parse: {array_str[:300]}"
        ) from e
    if not isinstance(result, list):
        raise ValueError("Parsed JSON is not a list.")
    return result


def _validate_test_cases(test_cases: list) -> list:
    """
    Validate and clean the parsed list of test case dicts.

    Silently drops invalid items with a printed warning. The pipeline
    must never crash due to a malformed individual test case.

    Args:
        test_cases: Raw list of dicts from _extract_json_array().

    Returns:
        List containing only valid test case dicts.
    """
    VALID_CATEGORIES = {"positive", "negative", "boundary", "malformed"}
    REQUIRED_KEYS = {"id", "scenario", "expected_outcome", "category"}
    valid = []
    for i, item in enumerate(test_cases):
        if not isinstance(item, dict):
            print(f"WARNING: Test case at index {i} is not a dict — skipping.")
            continue
        missing = REQUIRED_KEYS - item.keys()
        if missing:
            item_id = item.get("id", f"index-{i}")
            print(f"WARNING: Test case '{item_id}' missing keys {missing} — skipping.")
            continue
        if item["category"] not in VALID_CATEGORIES:
            item_id = item.get("id", f"index-{i}")
            print(
                f"WARNING: Test case '{item_id}' has invalid category "
                f"'{item['category']}' — skipping."
            )
            continue
        valid.append(item)
    return valid


def test_case_generation_node(state: AgentState) -> dict:
    """
    Test Case Generation Agent — Stage 4 of the HOLMESforOMNI pipeline.

    Consumes the approved requirements_spec and generates a structured list
    of logical test cases. Single LLM call. Parses a JSON array response.
    Validates each test case item before storing.

    Also resets judge_retry_count to 0 and pre-builds interrupt_payload
    for the downstream judge_test_cases / gate_test_cases cycle.

    Args:
        state: Current AgentState. Reads: requirements_spec.

    Returns:
        Partial AgentState dict with keys:
        current_stage, test_cases, interrupt_payload, judge_retry_count.
    """
    # Step 1: Load context and prompts
    tech_context = load_context_file("tech_context.md")
    system_prompt = load_prompt("test_case_generation_system")
    user_prompt = load_prompt(
        "test_case_generation_user",
        {
            "requirements_spec": state["requirements_spec"],
            "tech_context": tech_context,
        },
    )

    # Step 2: Call LLM
    response = call_llm(system_prompt=system_prompt, user_prompt=user_prompt)

    # Step 3: Parse and validate
    raw_list = _extract_json_array(response)
    test_cases = _validate_test_cases(raw_list)

    # Step 4: Pre-build interrupt_payload for the judge/gate cycle
    interrupt_payload = {
        "gate_name": "Review Test Cases",
        "data_to_review": test_cases,
        "context_message": f"{len(test_cases)} test cases generated. Pending judge evaluation.",
    }

    # Step 5: Return state dict
    return {
        "current_stage": PipelineStage.TEST_CASE_GENERATION,
        "test_cases": test_cases,
        "interrupt_payload": interrupt_payload,
        "judge_retry_count": 0,
    }
