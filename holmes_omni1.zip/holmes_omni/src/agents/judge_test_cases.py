import json
from src.state.state import AgentState, JudgeVerdict, PipelineStage
from src.agents.llm_client import call_llm
from src.prompts.prompt_loader import load_prompt


def _extract_json(response: str) -> dict:
    """
    Extract the trailing JSON block from the judge's LLM response string.

    Uses rfind('{') to locate the last opening brace, ensuring we
    always parse the final structured JSON block even if the LLM
    produces JSON-like text earlier in its response.

    Args:
        response: Raw string response from call_llm().

    Returns:
        Parsed dict with keys: verdict, score, feedback.

    Raises:
        ValueError: If no JSON block is found or the JSON is malformed.
    """
    start = response.rfind("{")
    if start == -1:
        raise ValueError(
            "Judge Test Cases returned no JSON block. "
            f"Raw response (first 300 chars): {response[:300]}"
        )
    try:
        return json.loads(response[start:])
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Judge Test Cases returned malformed JSON. "
            f"Parse error: {e}. "
            f"Attempted to parse: {response[start:start + 300]}"
        ) from e


def judge_test_cases_node(state: AgentState) -> dict:
    """
    Test Cases Judge — Stage 5 of the HOLMESforOMNI pipeline.

    Evaluates the test_cases list produced by Stage 4 against the judge rubric.
    Makes a single LLM call. Returns verdict, score, feedback, and updated
    interrupt_payload with the real judge context_message.

    Escalation logic lives here: if retry_count reaches 3, verdict is forced
    to NEEDS_HUMAN regardless of LLM output.

    Args:
        state: Current AgentState. Reads: test_cases, requirements_spec,
               judge_retry_count, interrupt_payload.

    Returns:
        Partial AgentState dict with keys:
        current_stage, judge_verdict, judge_score, judge_feedback,
        judge_retry_count, interrupt_payload.
    """
    # Step 1: Increment retry counter
    retry_count = state.get("judge_retry_count", 0) + 1

    # Step 2: Check for max retries BEFORE calling LLM
    if retry_count >= 3:
        verdict = JudgeVerdict.NEEDS_HUMAN
        score = 0
        feedback = "Maximum retries reached. Escalating to human review."
    else:
        # Step 3: Serialise test_cases for the prompt
        test_cases_str = json.dumps(state["test_cases"], indent=2)

        # Step 4: Load prompts and call LLM
        system_prompt = load_prompt("judge_test_cases_system")
        user_prompt = load_prompt(
            "judge_test_cases_user",
            {
                "test_cases": test_cases_str,
                "requirements_spec": state["requirements_spec"],
            },
        )
        response = call_llm(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )

        # Step 5: Parse response, map verdict
        parsed = _extract_json(response)
        verdict_str = parsed.get("verdict", "FAIL")
        score = int(parsed.get("score", 0))
        feedback = parsed.get("feedback", None)

        try:
            verdict = JudgeVerdict(verdict_str)
        except ValueError:
            verdict = JudgeVerdict.FAIL
            feedback = f"Judge returned unrecognised verdict '{verdict_str}'. Defaulting to FAIL."

    # Step 6: Update interrupt_payload context_message
    updated_payload = state["interrupt_payload"].copy()
    updated_payload["context_message"] = (
        f"Judge score: {score}/100. Verdict: {verdict.value}. "
        + (f"Feedback: {feedback}" if feedback else "No issues found.")
    )

    # Step 7: Return state dict
    return {
        "current_stage": PipelineStage.JUDGE_TEST_CASES,
        "judge_verdict": verdict,
        "judge_score": score,
        "judge_feedback": feedback,
        "judge_retry_count": retry_count,
        "interrupt_payload": updated_payload,
    }
