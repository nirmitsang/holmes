from __future__ import annotations
from typing import TypedDict, Optional
from enum import Enum


# ── Enums ──────────────────────────────────────────────────────────────────


class JudgeVerdict(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    NEEDS_HUMAN = "NEEDS_HUMAN"


class DataStrategy(str, Enum):
    SYNTHETIC = "SYNTHETIC"
    SOURCE = "SOURCE"
    HYBRID = "HYBRID"


class PipelineStage(str, Enum):
    INIT                 = "INIT"
    QA_INTERACTION       = "QA_INTERACTION"
    REQUIREMENTS_SPEC    = "REQUIREMENTS_SPEC"
    JUDGE_SPEC           = "JUDGE_SPEC"
    GATE_SPEC            = "GATE_SPEC"
    TEST_CASE_GENERATION = "TEST_CASE_GENERATION"
    JUDGE_TEST_CASES     = "JUDGE_TEST_CASES"
    GATE_TEST_CASES      = "GATE_TEST_CASES"
    DATA_STRATEGY        = "DATA_STRATEGY"
    DATA_GENERATION      = "DATA_GENERATION"
    SCRIPT_WRITING       = "SCRIPT_WRITING"
    JUDGE_SCRIPT         = "JUDGE_SCRIPT"
    GATE_SCRIPT          = "GATE_SCRIPT"
    SANDBOX_EXECUTION    = "SANDBOX_EXECUTION"
    SELF_HEALING         = "SELF_HEALING"
    GITLAB_PUSH          = "GITLAB_PUSH"
    COMPLETE             = "COMPLETE"
    ERROR                = "ERROR"


# ── AgentState ─────────────────────────────────────────────────────────────


class AgentState(TypedDict):

    # ── Stage 1: QA Interaction Agent ──────────────────────────────────
    # raw_requirement: The verbatim requirement string entered by the engineer.
    raw_requirement: str

    # clarified_requirement: The structured, enriched requirement after the
    # QA Interaction Agent has asked all clarifying questions and received answers.
    clarified_requirement: Optional[str]

    # confidence_score: 0.0–1.0. Agent does not proceed to Stage 2 below threshold.
    confidence_score: Optional[float]

    # clarification_questions: List of questions the agent asked during Stage 1.
    # Retained for audit trail and UI display.
    clarification_questions: Optional[list[str]]

    # ── Stage 2: Requirements Spec Generation ──────────────────────────
    # requirements_spec: Structured markdown requirements specification.
    requirements_spec: Optional[str]

    # ── Judge (Shared — reset to 0/None at the start of each judge cycle) ─
    # judge_verdict: The verdict from the most recent judge evaluation.
    judge_verdict: Optional[JudgeVerdict]

    # judge_score: 0–100 quality score assigned by the judge.
    judge_score: Optional[int]

    # judge_feedback: Actionable feedback string from the judge on a FAIL verdict.
    # The regenerating agent uses this as explicit instruction for improvement.
    judge_feedback: Optional[str]

    # judge_retry_count: Counts iterations within the current judge cycle only.
    # Reset to 0 when entering a new judge node. FAIL on iteration 3 → NEEDS_HUMAN.
    judge_retry_count: int

    # ── Stage 4: Test Case Generation ──────────────────────────────────
    # test_cases: List of logical test case dicts. Each dict contains:
    # { "id": str, "scenario": str, "expected_outcome": str, "category": str }
    # category values: "positive", "negative", "boundary", "malformed"
    # NO data, NO scripts — purely logical descriptions.
    test_cases: Optional[list[dict]]

    # ── Stage 6: Data Strategy ─────────────────────────────────────────
    # data_strategy: The human-selected data approach. Not auto-decided.
    data_strategy: Optional[DataStrategy]

    # ── Stage 7: Test Data Generation ──────────────────────────────────
    # test_data: List of dicts. Each entry maps a test_case id to its payload.
    # { "test_case_id": str, "payload": dict, "correlation_id": str }
    test_data: Optional[list[dict]]

    # ── Stage 8: Script Writing Agent ──────────────────────────────────
    # test_script: The complete pytest script as a single string.
    # Contains ONLY helper function calls. No raw Kafka or K8s code.
    test_script: Optional[str]

    # ── Stage 10: Sandbox Execution ────────────────────────────────────
    execution_stdout: Optional[str]
    execution_stderr: Optional[str]
    execution_exit_code: Optional[int]

    # ── Stage 11: Self-Healing Agent ───────────────────────────────────
    # healing_retry_count: Separate from judge_retry_count. Max 3 healing iterations.
    healing_retry_count: int

    # defect_flag: Set to True ONLY on AssertionError failures. Never on framework errors.
    # When True, the pipeline stops and drafts a Jira ticket. Self-healing is PROHIBITED.
    defect_flag: bool

    # jira_draft: Structured Jira ticket draft. Populated only when defect_flag is True.
    jira_draft: Optional[str]

    # ── Stage 12: GitLab Push ──────────────────────────────────────────
    gitlab_branch: Optional[str]
    gitlab_mr_url: Optional[str]
    gitlab_pipeline_status: Optional[str]

    # ── Human Gates (Shared interrupt payload structure) ───────────────
    # interrupt_payload: Standardised dict the Streamlit UI reads to render
    # the correct review screen. Shape is always:
    # {
    #     "gate_name": str,        # e.g. "Review Requirements Spec"
    #     "data_to_review": str | dict,  # the artifact being reviewed
    #     "context_message": str   # e.g. "Judge approved with score 92/100"
    # }
    # Reset to None after the human gate resolves.
    interrupt_payload: Optional[dict]

    # human_decision: Set by update_state() after human review.
    # Valid values (enforced by convention, not Enum): "APPROVED", "REJECTED", "EDITED"
    human_decision: Optional[str]

    # human_feedback: Free-text notes or edits from the engineer at any gate.
    human_feedback: Optional[str]

    # ── Pipeline Tracking ──────────────────────────────────────────────
    # current_stage: Always reflects the stage the pipeline is currently executing.
    current_stage: PipelineStage

    # error_message: Populated only on unrecoverable errors that send pipeline to ERROR stage.
    error_message: Optional[str]


# ── Factory ────────────────────────────────────────────────────────────────


def default_state(raw_requirement: str) -> AgentState:
    return AgentState(
        raw_requirement=raw_requirement,
        clarified_requirement=None,
        confidence_score=None,
        clarification_questions=None,
        requirements_spec=None,
        judge_verdict=None,
        judge_score=None,
        judge_feedback=None,
        judge_retry_count=0,
        test_cases=None,
        data_strategy=None,
        test_data=None,
        test_script=None,
        execution_stdout=None,
        execution_stderr=None,
        execution_exit_code=None,
        healing_retry_count=0,
        defect_flag=False,
        jira_draft=None,
        gitlab_branch=None,
        gitlab_mr_url=None,
        gitlab_pipeline_status=None,
        interrupt_payload=None,
        human_decision=None,
        human_feedback=None,
        current_stage=PipelineStage.INIT,
        error_message=None,
    )
