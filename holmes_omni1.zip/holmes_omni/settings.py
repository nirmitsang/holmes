"""
Application settings loaded from .env via pydantic-settings.
No logic here. Only configuration binding.
"""
from pydantic_settings import BaseSettings
from pydantic import Field
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    aws_region: str = Field(..., env="AWS_REGION")
    aws_access_key_id: str = Field(..., env="AWS_ACCESS_KEY_ID")
    aws_secret_access_key: str = Field(..., env="AWS_SECRET_ACCESS_KEY")
    bedrock_model_id: str = Field(..., env="BEDROCK_MODEL_ID")
    log_level: str = Field(default="INFO", env="LOG_LEVEL")

    model_config = {"env_file": ".env", "extra": "ignore"}

settings = Settings()
