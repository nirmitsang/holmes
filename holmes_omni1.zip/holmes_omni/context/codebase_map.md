# Codebase Map — Helper Function Library

## Import Path
```python
from src.helpers.kafka_helpers import kafka_produce_message, kafka_produce_batch, kafka_consume_messages, kafka_consume_by_correlation_id, kafka_purge_topic
from src.helpers.openshift_helpers import get_pod_status, get_pod_logs, restart_pod, wait_for_pod_ready
from src.helpers.test_utils import generate_correlation_id, assert_message_in_topic, assert_message_not_in_topic
from src.helpers.reporting import generate_allure_report
```

## Kafka Helpers
- `kafka_produce_message(topic: str, payload: dict, headers: dict = None) -> int`
- `kafka_produce_batch(topic: str, payloads: list[dict]) -> list[int]`
- `kafka_consume_messages(topic: str, timeout_seconds: int, expected_count: int) -> list[dict]`
- `kafka_consume_by_correlation_id(topic: str, correlation_id: str, timeout_seconds: int) -> dict | None`
- `kafka_purge_topic(topic: str) -> bool`

## OpenShift Helpers
- `get_pod_status(namespace: str, pod_name_prefix: str) -> str`
- `get_pod_logs(namespace: str, pod_name_prefix: str, tail_lines: int = 100) -> str`
- `restart_pod(namespace: str, pod_name_prefix: str) -> bool`
- `wait_for_pod_ready(namespace: str, pod_name_prefix: str, timeout_seconds: int) -> bool`

## Test Utility Helpers
- `generate_correlation_id() -> str`
- `assert_message_in_topic(topic: str, expected_payload: dict, timeout_seconds: int) -> bool`
- `assert_message_not_in_topic(topic: str, payload_key: str, timeout_seconds: int) -> bool`

## Reporting
- `generate_allure_report(results: dict) -> None`

## pytest Conventions
- Test files: test_<feature>.py
- Test functions: test_<scenario>_<expected_outcome>
- Fixtures: defined in conftest.py
- Allure decorators: @allure.feature(), @allure.story(), @allure.severity()
