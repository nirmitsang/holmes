# OMNI Platform — Technical Context

## Architecture Overview
OMNI is a real-time transaction lineage platform. Data flows:
Source Payment Teams → K Streams Ingestion Job → Kafka → K Streams Jurisdiction Job → [Compliant Topic | Non-Compliant Topic] → Cloud Mirror → Flink ETL → Snowpipe → Snowflake → REST API → UI

## Phase 1 Scope: Jurisdiction K Streams Job
**Input Topic:** PLACEHOLDER_INPUT_TOPIC
**Compliant Output Topic:** PLACEHOLDER_COMPLIANT_TOPIC
**Non-Compliant Output Topic:** PLACEHOLDER_NON_COMPLIANT_TOPIC

## Jurisdiction Business Rules
PLACEHOLDER — to be populated with real rules before running any session.
Example structure:
- IF transaction.region IN ["EU", "UK"] AND transaction.restricted_entity == false → route to COMPLIANT topic
- ELSE → route to NON_COMPLIANT topic

## Environment
- Kafka Bootstrap Server: PLACEHOLDER_BOOTSTRAP_SERVER
- Auth Method: PLACEHOLDER_AUTH_METHOD
- OpenShift Namespace: PLACEHOLDER_NAMESPACE
- Pod Name Prefix: PLACEHOLDER_POD_PREFIX

## PII / Compliance Note
This is a corporate banking platform. Never send real transaction payload values to the LLM.
Schema field names and business rule descriptions are permitted. Real field values are not.
