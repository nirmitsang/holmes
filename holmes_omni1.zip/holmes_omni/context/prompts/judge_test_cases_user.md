TEST CASES UNDER EVALUATION:

{test_cases}

---

REQUIREMENTS SPECIFICATION (for reference — judge coverage against this):

{requirements_spec}

---

Evaluate the test cases above against the rubric in your instructions. Be precise and consistent. Your feedback will be used directly by the regenerating agent — it must be specific enough to act on.
