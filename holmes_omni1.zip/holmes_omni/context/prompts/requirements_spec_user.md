CLARIFIED REQUIREMENT:
{clarified_requirement}

TECHNICAL CONTEXT:
{tech_context}

Produce the requirements specification document following the mandatory
six-section structure defined in your instructions. Use only the information
provided above. Write UNKNOWN for anything not specified. Do not invent
field names, topic names, or business rules.
