REQUIREMENTS SPECIFICATION UNDER EVALUATION:

{requirements_spec}

---

ORIGINAL CLARIFIED REQUIREMENT (for reference — judge against this):

{clarified_requirement}

---

Evaluate the requirements specification above against the rubric in your instructions. Be precise and consistent. Your feedback will be used directly by the regenerating agent — it must be specific enough to act on.
