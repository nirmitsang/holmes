REQUIREMENTS SPECIFICATION:

{requirements_spec}

---

TECHNICAL CONTEXT:

{tech_context}

---

Generate the complete set of test cases following the mandatory structure and coverage rules defined in your instructions. Output only the JSON array. No other text.
