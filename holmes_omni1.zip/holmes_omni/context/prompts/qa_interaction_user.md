RELEASE REQUIREMENT:
{raw_requirement}

CLARIFICATION ROUND: {clarification_round}
(1 = first analysis, 2 = follow-up after engineer answered your questions)

ENGINEER'S ANSWERS TO PREVIOUS QUESTIONS (if round 2):
{engineer_answers}

TECHNICAL CONTEXT:
{tech_context}

Analyse the requirement. Apply the mandatory information checklist.
Score your confidence. If below 0.85 and this is round 1, ask your
clarifying questions. If this is round 2, consolidate all known information
and produce your final confidence score and clarified requirement regardless
of score. End your response with the required JSON block.
