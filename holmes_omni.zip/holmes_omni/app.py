import streamlit as st
from langgraph.types import Command
from langgraph.errors import GraphInterrupt
from src.graph.builder import build_graph
from src.state.state import default_state, PipelineStage


st.set_page_config(
    page_title="HOLMESforOMNI",
    page_icon="🔍",
    layout="centered",
)


@st.cache_resource
def get_graph():
    return build_graph()


def init_session_state():
    defaults = {
        "pipeline_running": False,
        "pipeline_complete": False,
        "awaiting_interrupt": False,
        "interrupt_payload": None,
        "thread_id": None,
        "current_stage": None,
        "requirements_spec": None,
        "test_cases": None,
        "judge_history": [],
        "error_message": None,
        "run_counter": 0,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def _sync_state_from_snapshot(values: dict):
    if values.get("current_stage"):
        st.session_state.current_stage = values["current_stage"]
    if values.get("requirements_spec"):
        st.session_state.requirements_spec = values["requirements_spec"]
    if values.get("test_cases"):
        st.session_state.test_cases = values["test_cases"]
    if values.get("interrupt_payload"):
        st.session_state.interrupt_payload = values["interrupt_payload"]
    # Append judge result to history if a verdict is present
    if values.get("judge_verdict") and values.get("current_stage"):
        entry = {
            "stage": str(values["current_stage"]),
            "verdict": str(values.get("judge_verdict")),
            "score": values.get("judge_score"),
            "feedback": values.get("judge_feedback"),
        }
        # Avoid duplicate entries
        if entry not in st.session_state.judge_history:
            st.session_state.judge_history.append(entry)


def _run_pipeline(requirement: str):
    graph = get_graph()
    st.session_state.run_counter += 1
    thread_id = f"holmes-thread-{st.session_state.run_counter}"
    st.session_state.thread_id = thread_id
    st.session_state.pipeline_running = True
    st.session_state.pipeline_complete = False
    st.session_state.awaiting_interrupt = False
    st.session_state.judge_history = []
    st.session_state.error_message = None

    config = {"configurable": {"thread_id": thread_id}}
    initial_state = default_state(requirement)

    try:
        result = graph.invoke(initial_state, config=config)
        _sync_state_from_snapshot(result)
        # LangGraph 1.0.7 returns state silently on interrupt — never raises.
        # Check snapshot.next to determine if graph is paused or truly complete.
        snapshot = graph.get_state(config)
        if snapshot.next:
            st.session_state.awaiting_interrupt = True
            st.session_state.pipeline_complete = False
            _sync_state_from_snapshot(snapshot.values)
        else:
            st.session_state.pipeline_complete = True
            st.session_state.awaiting_interrupt = False
    except Exception as e:
        st.session_state.error_message = str(e)
    finally:
        st.session_state.pipeline_running = False


def _resume_pipeline(resume_value):
    graph = get_graph()
    config = {"configurable": {"thread_id": st.session_state.thread_id}}
    st.session_state.awaiting_interrupt = False
    st.session_state.interrupt_payload = None
    st.session_state.pipeline_running = True

    try:
        result = graph.invoke(Command(resume=resume_value), config=config)
        _sync_state_from_snapshot(result)
        # Same pattern — check snapshot.next, not exceptions.
        snapshot = graph.get_state(config)
        if snapshot.next:
            st.session_state.awaiting_interrupt = True
            st.session_state.pipeline_complete = False
            _sync_state_from_snapshot(snapshot.values)
        else:
            st.session_state.pipeline_complete = True
            st.session_state.awaiting_interrupt = False
    except Exception as e:
        st.session_state.error_message = str(e)
    finally:
        st.session_state.pipeline_running = False


def _render_interrupt_handler():
    payload = st.session_state.interrupt_payload
    if payload is None:
        return

    gate_name = payload.get("gate_name", "")
    data_to_review = payload.get("data_to_review")
    context_message = payload.get("context_message", "")

    st.markdown("---")
    st.subheader(gate_name)
    st.caption(context_message)

    # MODE 1: QA Clarification — plain text input, returns plain string
    if gate_name.startswith("QA Clarification"):
        if isinstance(data_to_review, list):
            for i, q in enumerate(data_to_review, 1):
                st.markdown(f"**{i}.** {q}")
        answers = st.text_area(
            "Your answers",
            key=f"qa_answers_{gate_name}",
            height=150,
            placeholder="Answer the questions above. Be specific.",
        )
        if st.button("Submit Answers", key=f"qa_submit_{gate_name}"):
            if answers.strip():
                _resume_pipeline(answers.strip())
                st.rerun()
            else:
                st.warning("Please provide answers before submitting.")

    # MODE 2: Gate review — approve / reject / edit, returns standard dict
    else:
        if isinstance(data_to_review, str):
            with st.expander("View Artifact", expanded=True):
                st.markdown(data_to_review)
        elif isinstance(data_to_review, list):
            with st.expander(f"View {len(data_to_review)} items", expanded=True):
                st.json(data_to_review)

        st.markdown("**Your Decision**")
        feedback = st.text_area(
            "Feedback (required on Reject, optional on Approve)",
            key=f"gate_feedback_{gate_name}",
            height=100,
        )
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("✅ Approve", key=f"approve_{gate_name}", use_container_width=True):
                _resume_pipeline({"decision": "APPROVED", "feedback": feedback})
                st.rerun()
        with col2:
            if st.button("✏️ Approve with Edit", key=f"edit_{gate_name}", use_container_width=True):
                _resume_pipeline({"decision": "EDITED", "feedback": feedback})
                st.rerun()
        with col3:
            if st.button("❌ Reject", key=f"reject_{gate_name}", use_container_width=True):
                if feedback.strip():
                    _resume_pipeline({"decision": "REJECTED", "feedback": feedback})
                    st.rerun()
                else:
                    st.warning("Feedback is required when rejecting.")


STAGE_ORDER = [
    PipelineStage.QA_INTERACTION,
    PipelineStage.REQUIREMENTS_SPEC,
    PipelineStage.JUDGE_SPEC,
    PipelineStage.GATE_SPEC,
    PipelineStage.TEST_CASE_GENERATION,
    PipelineStage.JUDGE_TEST_CASES,
    PipelineStage.GATE_TEST_CASES,
    PipelineStage.DATA_STRATEGY,
    PipelineStage.DATA_GENERATION,
    PipelineStage.SCRIPT_WRITING,
    PipelineStage.JUDGE_SCRIPT,
    PipelineStage.GATE_SCRIPT,
    PipelineStage.SANDBOX_EXECUTION,
    PipelineStage.SELF_HEALING,
    PipelineStage.GITLAB_PUSH,
]

STAGE_LABELS = {
    PipelineStage.QA_INTERACTION: "1 · QA Interaction",
    PipelineStage.REQUIREMENTS_SPEC: "2 · Requirements Spec",
    PipelineStage.JUDGE_SPEC: "3 · Judge: Spec",
    PipelineStage.GATE_SPEC: "4 · Gate: Spec Review",
    PipelineStage.TEST_CASE_GENERATION: "5 · Test Case Generation",
    PipelineStage.JUDGE_TEST_CASES: "6 · Judge: Test Cases",
    PipelineStage.GATE_TEST_CASES: "7 · Gate: Test Cases Review",
    PipelineStage.DATA_STRATEGY: "8 · Data Strategy",
    PipelineStage.DATA_GENERATION: "9 · Data Generation",
    PipelineStage.SCRIPT_WRITING: "10 · Script Writing",
    PipelineStage.JUDGE_SCRIPT: "11 · Judge: Script",
    PipelineStage.GATE_SCRIPT: "12 · Gate: Script Review",
    PipelineStage.SANDBOX_EXECUTION: "13 · Sandbox Execution",
    PipelineStage.SELF_HEALING: "14 · Self-Healing",
    PipelineStage.GITLAB_PUSH: "15 · GitLab Push",
}


def _render_stage_tracker():
    stage = st.session_state.current_stage
    if stage is None:
        return

    st.markdown("---")
    st.caption("PIPELINE PROGRESS")

    current_index = -1
    for i, s in enumerate(STAGE_ORDER):
        if s == stage:
            current_index = i
            break

    cols = st.columns(len(STAGE_ORDER))
    for i, s in enumerate(STAGE_ORDER):
        with cols[i]:
            if i < current_index:
                st.markdown("✓")
            elif i == current_index:
                st.markdown("●")
            else:
                st.markdown("·")

    st.caption(f"**{STAGE_LABELS.get(stage, str(stage))}**")

    if st.session_state.judge_history:
        st.markdown("---")
        st.caption("JUDGE HISTORY")
        for entry in st.session_state.judge_history:
            verdict = entry["verdict"]
            score = entry["score"]
            feedback = entry.get("feedback")
            icon = "✅" if "PASS" in verdict else ("⚠️" if "NEEDS_HUMAN" in verdict else "🔄")
            label = STAGE_LABELS.get(entry["stage"], entry["stage"])
            if feedback:
                with st.expander(f"{icon} {label} — {verdict} ({score}/100)"):
                    st.caption(feedback)
            else:
                st.caption(f"{icon} {label} — {verdict} ({score}/100)")


def _render_artifacts():
    has_spec = st.session_state.requirements_spec is not None
    has_cases = st.session_state.test_cases is not None

    if not has_spec and not has_cases:
        return

    st.markdown("---")
    st.caption("ARTIFACTS")

    if has_spec:
        with st.expander("Requirements Specification", expanded=False):
            st.markdown(st.session_state.requirements_spec)

    if has_cases:
        cases = st.session_state.test_cases
        with st.expander(f"Test Cases  ({len(cases)} total)", expanded=False):
            # Category summary row
            from collections import Counter
            counts = Counter(c.get("category", "unknown") for c in cases)
            cols = st.columns(4)
            labels = ["positive", "negative", "boundary", "malformed"]
            for i, cat in enumerate(labels):
                with cols[i]:
                    st.metric(cat.capitalize(), counts.get(cat, 0))

            st.markdown("---")
            for case in cases:
                st.markdown(f"**{case.get('id')}** · `{case.get('category')}`")
                st.markdown(f"{case.get('scenario')}")
                st.caption(f"→ {case.get('expected_outcome')}")
                st.markdown("---")


def main():
    init_session_state()

    st.title("HOLMESforOMNI")
    st.caption("Autonomous STLC · Jurisdiction K Streams · MVP Phase 1")
    st.markdown("---")

    # ── Input section — only shown when pipeline is not running ──
    if not st.session_state.pipeline_running and not st.session_state.awaiting_interrupt:
        requirement = st.text_area(
            "Release Requirement",
            height=180,
            placeholder="Describe the Jurisdiction K Streams change...",
            key="requirement_input",
        )
        if st.button("Run Pipeline", type="primary", use_container_width=True):
            if requirement.strip():
                _run_pipeline(requirement.strip())
                st.rerun()
            else:
                st.warning("Please enter a requirement before running.")

    # ── Running indicator ──
    if st.session_state.pipeline_running:
        with st.spinner("Pipeline running..."):
            st.empty()

    # ── Stage tracker ──
    _render_stage_tracker()

    # ── Artifacts ──
    _render_artifacts()

    # ── Interrupt handler ──
    if st.session_state.awaiting_interrupt:
        _render_interrupt_handler()

    # ── Error display ──
    if st.session_state.error_message:
        st.error(f"Pipeline error: {st.session_state.error_message}")
        if st.button("Reset", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()

    # ── Completion ──
    if st.session_state.pipeline_complete:
        st.success("Pipeline complete.")
        if st.button("Start New Run", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()


if __name__ == "__main__":
    main()
