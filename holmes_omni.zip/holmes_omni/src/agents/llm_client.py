import json
import boto3
from botocore.exceptions import ClientError
from settings import settings


def call_llm(
    system_prompt: str,
    user_prompt: str,
    max_tokens: int = 16000,
) -> str:
    """
    Single entry point for all LLM calls in the HOLMESforOMNI pipeline.

    Calls AWS Bedrock with Claude 3.7 Sonnet using extended thinking (always on).
    Temperature is hardcoded to 1 — required by the Bedrock API when extended
    thinking is enabled. Do not add a temperature parameter.

    Args:
        system_prompt: The agent's role and behavioural instructions.
        user_prompt: The specific task input for this call.
        max_tokens: Total token budget including thinking tokens. Default 8000.

    Returns:
        The text content of the model's response as a plain string.

    Raises:
        RuntimeError: On any Bedrock ClientError or unexpected response shape.
    """
    try:
        client = boto3.client(
            "bedrock-runtime",
            region_name=settings.aws_region,
            aws_access_key_id=settings.aws_access_key_id or None,
            aws_secret_access_key=settings.aws_secret_access_key or None,
            aws_session_token=settings.aws_session_token or None,
        )

        native_request = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": 1,
            "thinking": {
                "type": "enabled",
                "budget_tokens": 8000,
            },
            "system": system_prompt,
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": user_prompt}],
                }
            ],
        }

        response = client.invoke_model(
            modelId=settings.bedrock_model_id,
            body=json.dumps(native_request),
        )

        model_response = json.loads(response["body"].read())
        content_blocks = model_response.get("content", [])
        text_blocks = [b for b in content_blocks if b.get("type") == "text"]

        if not text_blocks:
            raise RuntimeError(
                "LLM call returned no text content block. "
                f"Full response: {model_response}"
            )

        return text_blocks[0]["text"]

    except ClientError as e:
        raise RuntimeError(f"Bedrock ClientError: {e}") from e
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError(f"Unexpected LLM call failure: {e}") from e
